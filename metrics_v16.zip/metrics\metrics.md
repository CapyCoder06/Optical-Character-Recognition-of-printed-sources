## Evaluation Summary

- **Coverage**: 3 / 60 pages
- **CER (raw, mean)**: 1.1371296296296296
- **WER (raw, mean)**: 1.2051467051467053
- **CER (corrected, mean)**: 1.1320041816009558
- **WER (corrected, mean)**: 1.1892736892736893
